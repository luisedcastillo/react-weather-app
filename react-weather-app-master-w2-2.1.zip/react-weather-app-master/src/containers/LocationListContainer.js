import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { setSelectedCity, setWeather } from '../actions';
import { getCitiesWeather } from '../reducers';
import LocationList from '../components/LocationList';

class LocationListContainer extends Component {

    componentDidMount() {
        this.props.setWeather(this.props.cities)
    }

    handleLocationSelected = city => {
        this.props.setSelectedCity(city);
    }

    render() {
        return (
            /* jshint ignore:start */ // JSX is not supported
            <LocationList 
                cities={this.props.citiesWeather}
                onLocationSelected={this.handleLocationSelected}>
            </LocationList>
            /* jshint ignore:end */ // JSX is not supported
        );
    }
}

LocationListContainer.propTypes = {
    setSelectedCity: PropTypes.func.isRequired,
    cities: PropTypes.array.isRequired,
    citiesWeather: PropTypes.array,
};

const mapDispatcherToProps = dispatch => ({
    setSelectedCity: value => dispatch(setSelectedCity(value)),
    setWeather: cities => dispatch(setWeather(cities))
});

const mapStateToProps = state => ({citiesWeather: getCitiesWeather(state)});

export default connect(mapStateToProps, mapDispatcherToProps)(LocationListContainer);