import React from 'react';
import PropTypes from 'prop-types';
import ForecastItem from './ForecastItem';
import '../styles.css';

const renderForecastItemDays = (forecastData) => {
    //console.log(forecastData);
    return forecastData.map(item => (
        /* jshint ignore:start */ // JSX is not supported
        <ForecastItem 
            weekDay={item.weekDay} 
            hour={item.hour} 
            data={item.data}
            key={`${item.weekDay}${item.hour}`}></ForecastItem>
        /* jshint ignore:end */ // JSX is not supported
    ));
};

const renderProgess = () => {
    return 'Loading.....';
};

const ForecastExtended = ({city, forecastData}) => {
    console.log(forecastData);
    return (
        /* jshint ignore:start */ // JSX is not supported
        <div>
            <h3 className="forecast-title">Pronostico extendido para {city}</h3>
            { forecastData
                ? renderForecastItemDays(forecastData)
                : renderProgess()
            }
        </div>  
        /* jshint ignore:end */ // JSX is not supported
    );
}

ForecastExtended.propTypes = {
    city: PropTypes.string.isRequired,
    forecastData: PropTypes.array.isRequired,
};

export default ForecastExtended;