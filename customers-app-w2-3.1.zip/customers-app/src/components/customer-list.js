import React from 'react';
import PropTypes from 'prop-types';

const customerRender = (customers, baseUrl) => {
    return customers &&
            customers.map(customer => (
                <CustomerListItem
                    key={customer.id}
                    name={customer.name}
                    editAction={'editar'}
                    deleteAction={'eliminar'}
                    baseUrl={baseUrl}>
                </CustomerListItem>
            ));
};

const CustomerList = ({customers, baseUrl}) => {
    return (
        <div className="customer-list">
            {
                customerRender(customers, baseUrl)
            }
        </div>
    );
};

CustomerList.propTypes = {
    customers: PropTypes.arrayOf(PropTypes.shape({
        name: PropTypes.string.isRequired,
        id: PropTypes.string.isRequired,
        editAction: PropTypes.string.isRequired,
        deleteAction: PropTypes.string.isRequired,
    })).isRequired,
    baseUrl: PropTypes.string.isRequired,
};

export default CustomerList;