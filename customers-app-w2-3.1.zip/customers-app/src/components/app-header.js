import React from 'react';
import PropTypes from 'prop-types';

const AppHeader = ({title}) => {
    return (
        <div className="app-header">
            <h2>{title}</h2>
        </div>
    );
};

AppHeader.propTypes = {
    title: PropTypes.string.isRequired,
}

export default AppHeader;
