import React from 'react';
import PropTypes from 'prop-types';

const CustomerListItem = ({name, id, editAction, deleteAction, baseUrl}) => {
    return (
        <div className="customers-list-item">
            <div className="field">
                <Link to={`${baseUrl}/${id}`}>{name}</Link>
            </div>
            <div className="field">
                <Link to={`${baseUrl}/${id}/delete`}>{editAction}</Link>
            </div>
            <div className="field">
                <Link to={`${baseUrl}/${id}/delete`}>{deleteAction}</Link>
            </div>
        </div>
    );
};

CustomerListItem.propTypes = {
    name: PropTypes.string.isRequired,
    id: PropTypes.string.isRequired,
    editAction: PropTypes.string.isRequired,
    deleteAction: PropTypes.string.isRequired,
    baseUrl: PropTypes.string.isRequired,
};

export default CustomerListItem;