import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';
import AppFrame from './../components/app-frame';
import CustomerActions from './../components/customer-actions';

class HomeContainer extends Component {
    render(){
        return(
            <div className="home-container">
                <AppFrame
                    header="Home"
                    body={
                        <div>
                            Esta es la pantalla inicial
                            <CustomerActions>
                                <Link to="/customers">Listado de clientes</Link>
                            </CustomerActions>
                        </div>
                    }>
                </AppFrame>
            </div>
        );
    }
};

HomeContainer.propTypes = {

};

export default HomeContainer;