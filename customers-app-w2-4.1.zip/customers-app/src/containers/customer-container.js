import React, { Component } from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import AppFrame from './../components/app-frame';

class CustomerContainer extends Component {
    render(){
        const { id, customer } = this.props;
        return (
            <div>
                <AppFrame 
                        header="Cliente"
                        body={<div>INFO CLIENTE: {id}---{customer.name}</div>}>
                </AppFrame>
            </div>
        );
    }
};

CustomerContainer.propTypes = {
    id: PropTypes.string.isRequired,
    customer: PropTypes.object.isRequired,
};

const mapStateToProps = (state, props) => ({
    customer: state.customers.find(c => c.id === props.id)
});

export default connect(customer, null)(CustomerContainer);

