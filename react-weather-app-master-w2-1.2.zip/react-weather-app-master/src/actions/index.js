import {getForecastUrlByCity} from './../../services/getUrls';
import convertForecast from './../../services/convertForecast';

export const SET_CITY = 'SET_CITY';

export const setCity = city => ({ type: SET_CITY, payload: city });

export const fetchForecast = payload => {
    return dispatch => {
        //fetch or axios
        const apiForecast= getForecastUrlByCity(city);
        
        // Ejecutando busqueda => indicador

        fetch(apiForecast)
        .then(resolve => {
            return resolve.json();
        })
        .then(data => {
            const forecastData = convertForecast(data);
            //Modificar el estado con el resultado de la promise
        });

        return;
    };
};
    