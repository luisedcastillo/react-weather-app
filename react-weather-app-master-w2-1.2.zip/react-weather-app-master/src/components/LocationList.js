import React from 'react';
import PropTypes from 'prop-types';
import WeatherLocation from './WeatherLocation';
import './styles.css';


const LocationList = ({cities, onLocationSelected}) => {
    
    const handleWeatherLocationClick = city => {
        console.log('handleWeatherLocationClick');
        onLocationSelected(city);
    };


    const getComponents = cities => (
        /* jshint ignore:start */ // JSX is not supported
        cities.map(city => 
            <WeatherLocation 
                key={city} 
                city={city}
                onWeatherLocationClick={() => handleWeatherLocationClick(city)}>
            </WeatherLocation>
        )
        /* jshint ignore:end */ // JSX is not supported
    );
    
    return (
        /* jshint ignore:start */ // JSX is not supported
        <div className='locationList'>
            {getComponents(cities)}
        </div>
        /* jshint ignore:end */ // JSX is not supported
    );
};

LocationList.propTypes = {
    cities: PropTypes.array.isRequired,
    onLocationSelected: PropTypes.func
};

export default LocationList