import React, {Component} from 'react';
import PropTypes from 'prop-types';
import ForecastItem from './ForecastItem';
import {getForecastUrlByCity} from './../../services/getUrls';
import convertForecast from './../../services/convertForecast';
import '../styles.css';

// const days= [
//     'Lunes',
//     'Martes',
//     'Miercoles',
//     'Jueves',
//     'Viernes'
// ];

// const data = {
//     temp: 23,
//     humidity: 12,
//     weatherState: 'normal',
//     wind: 'tst'
// };

class ForecastExtended extends Component {

    constructor(props){
        super(props);
        this.state = {
            forecastData: null
        };
    }

    componentDidMount() {
        this.updateCity(this.props.city);
    }

    componentWillReceiveProps(nextProps) {
        if(nextProps.city !== this.props.city){
            this.setState({
                forecastData: null
            });
            this.updateCity(nextProps.city);
        }
    }
    

    updateCity(city) {
        //fetch or axios
        const apiForecast= getForecastUrlByCity(city);
        
        fetch(apiForecast)
        .then(resolve => {
            // console.log(resolve);
            return resolve.json();
        })
        .then(data => {
            const forecastData = convertForecast(data);
            this.setState({
                forecastData
            });

            // const newWeather = convertWeather(data);
            // // console.log(newWeather);
            // this.setState({ 
            //     data: newWeather
            // });
        });
    }
    

    renderForecastItemDays(forecastData){
        //console.log(forecastData);
        return forecastData.map(item => (
            /* jshint ignore:start */ // JSX is not supported
            <ForecastItem 
                weekDay={item.weekDay} 
                hour={item.hour} 
                data={item.data}
                key={`${item.weekDay}${item.hour}`}></ForecastItem>
            /* jshint ignore:end */ // JSX is not supported
        ));
    }

    renderProgess() {
        return 'Loading.....';
    }

    render() {
        const {city} = this.props;
        const { forecastData } = this.state;
        return (
            /* jshint ignore:start */ // JSX is not supported
            <div>
                <h3 className="forecast-title">Pronostico extendido para {city}</h3>
                { forecastData
                    ? this.renderForecastItemDays(forecastData)
                    : this.renderProgess()
                }
            </div>  
            /* jshint ignore:end */ // JSX is not supported
        );
    }
}

ForecastExtended.propTypes = {
    city: PropTypes.string.isRequired
};

export default ForecastExtended;