export const apiKey = '6eeea786d7d8767e5832f03d1c2ba5e3';
export const weatherUrl = 'http://api.openweathermap.org/data/2.5/weather';
export const forecastUrl = 'http://api.openweathermap.org/data/2.5/forecast';
