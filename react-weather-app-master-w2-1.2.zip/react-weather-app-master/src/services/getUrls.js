import { apiKey, weatherUrl, forecastUrl } from '../constants/apiUrls'

export const getWeatherUrlByCity = city => {
   return `${weatherUrl}?q=${city}&appid=${apiKey}`;
};

export const getForecastUrlByCity = city => {
    return `${forecastUrl}?q=${city}&appid=${apiKey}`;
 };