import React from 'react';

const AboutContainer = () => {
    return(
        <div>ABOUT</div>
    );
};

export default AboutContainer;