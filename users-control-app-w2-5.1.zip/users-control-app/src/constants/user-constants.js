export const WOMEN = 'women';
export const MEN = 'men';
export const FEMALE = 'female';
export const MALE = 'male';