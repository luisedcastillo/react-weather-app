import React from 'react';
import PropTypes from 'prop-types';
import AppHeader from './app-header';

const AppFrame = ({header, body}) => {
    return (
        <div className="app-frame">
            <AppHeader title={header}></AppHeader>
            <div>{body}</div>
            <div>FOOTER</div>
        </div>
    );
};

AppFrame.propTyes = {
    header: PropTypes.string.isRequired,
    body: PropTypes.string.isRequired,
}

export default AppFrame;