import React from 'react';
import PropTypes from 'prop-types';
import { reduxForm, Field } from 'redux-form';
import { withInitialValues } from '../higher-order-components/with-initial-values';

const CustomerEdit = ({name, id, age}) => {
    return (
        <div className="customer-edit">
            <h3>Editar cliente:</h3>
            <form>
                <div>
                    <label htmlFor="name">Nombre</label>
                    <Field name="name" component="input" type="text"></Field>
                </div>
                <div>
                    <label htmlFor="id">ID</label>
                    <Field name="id" component="input" type="text"></Field>
                </div>
                <div>
                    <label htmlFor="age">Edad</label>
                    <Field name="age" component="input" type="number"></Field>
                </div>
            </form>
        </div>
    );
};

CustomerEdit.propTypes = {
    name: PropTypes.string.isRequired,
    id: PropTypes.string.isRequired,
    age: PropTypes.number.isRequired,
};

const customerEditForm = reduxForm({form: 'CustomerEdit'})(CustomerEdit);

export default withInitialValues(customerEditForm);