import React, { Component } from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { Route } from 'react-router-dom';
import { getCustomerById } from './../selectors/customers';
import AppFrame from './../components/app-frame';
import CustomerEdit from './../components/customer-edit';
import CustomerData from './../components/customer-data';

class CustomerContainer extends Component {

    renderBody = () => (
        <Route path="/customers/:id/edit" children={
            ({match}) => { 
                const CustomerControl = match ? CustomerEdit : CustomerData; 
                return <CustomerControl {...this.props.customer}/>
                           
            }
        } /> 
    )
    
    render(){
        const { id, customer } = this.props;
        return (
            <div>
                <AppFrame 
                        header={`Cliente ${customer.name}`}
                        body={this.renderBody()}>
                </AppFrame>
            </div>
        );
    }
};

CustomerContainer.propTypes = {
    id: PropTypes.string.isRequired,
    customer: PropTypes.object.isRequired,
};

const mapStateToProps = (state, props) => ({
    customer: getCustomerById(state, props)
});

export default connect(mapStateToProps, null)(CustomerContainer);

