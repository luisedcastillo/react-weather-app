import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux'
import {fetchCustomers } from './../actions/fetchCustomers';
import CustomerList from './../components/customer-list';
import AppFrame from '../components/app-frame';
import CustomerActions from '../components/customer-actions';
import { getCustomers } from './../selectors/customers';

class CustomersContainer extends Component {

    componentDidMount() {
        this.props.fetchCustomers();
    }
    

    handleAddNew = () => {
        this.props.history.push('customers/new');
    }
    
    renderBody = customers => (
        <div>
            <CustomerList 
                customers={customers}
                baseUrl='customers'>
            </CustomerList>
            <CustomerActions>
                <button onClick={this.handleAddNew}>Nuevo Cliente</button>
            </CustomerActions>
        </div>
    )

    render(){
        return (
            <div className="customers-container">
                <AppFrame
                    header="Listado de Clientes"
                    body={this.renderBody(this.props.customers)}>

                </AppFrame>
            </div>
        );
    }
}

CustomersContainer.propTypes = {
    fetchCustomers: PropTypes.func.isRequired,
    customers: PropTypes.array.isRequired,
};

CustomersContainer.defaultProps = {
    customers: []
};

// const mapDispatchToProps = dispatch => ({
//     fetchCustomers: () => dispatch(fetchCustomers({}))    
// });

const mapDispatchToProps = {
    fetchCustomers
}

const mapStateToProps = state => ({
    customers: getCustomers(state)
});

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(CustomersContainer));