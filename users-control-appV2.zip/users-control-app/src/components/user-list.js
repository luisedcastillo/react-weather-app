import React from 'react';
import User from './user';

const UserList = () => {
    return (
         /* jshint ignore:start */ // JSX is not supported
        <div>
            User List
            <User></User>
        </div>
     /* jshint ignore:end */
    );
};

export default UserList;