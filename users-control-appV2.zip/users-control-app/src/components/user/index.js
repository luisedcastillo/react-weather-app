import React from 'react';
import UserData from './userData';

const User = () => {
    return (
         /* jshint ignore:start */ // JSX is not supported
        <div>
            User
            <UserData></UserData>
        </div>
     /* jshint ignore:end */
    );
};

export default User;