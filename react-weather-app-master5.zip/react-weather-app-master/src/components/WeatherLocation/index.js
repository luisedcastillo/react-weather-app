import React, { Component } from 'react';
import CircualrProgress from '@material-ui/core/CircularProgress'
import { PropTypes } from 'prop-types';
import Location from './Locartion';
import WeatherData from './WeatherData';
import convertWeather from './../../services/converterWeather';
import getWeatherUrlByCity from './../../services/getWeatherUrlByCity';
import './styles.css';

class WeatherLocation extends Component {

    constructor(props){
        super(props);

        const { city } = props;
        
        this.state = {
            city,
            data: null
        };

        // console.log('constructor');
        // ESTE BINDING ES NECESARIO PARA UTILIZAR "THIS" DENTRO DE HANDLECLICK
        this.handleUpdateClick = this.handleUpdateClick.bind(this);
    }

    componentDidMount() {
        // console.log('componentDidMount');
        this.handleUpdateClick();
    }

    componentDidUpdate(prevProps, prevState) {
        // console.log('componentDidUpdate');
    }

    // handleUpdateClick = () => { 
    //     data.humidity += 1;
    //     this.setState(data);
    //     console.log("actualizar info.....");
    // }

    handleUpdateClick(){ 
        // console.log('handleUpdateClick');
        const apiWeather = getWeatherUrlByCity(this.state.city);
        fetch(apiWeather)
        .then(resolve => {
            // console.log(resolve);
            return resolve.json();
        })
        .then(data => {
            // console.log('fetch data');
            const newWeather = convertWeather(data);
            // console.log(newWeather);
            this.setState({ 
                data: newWeather
            });
        });
    }
    
    //render = () => {
    render() {
        const {onWeatherLocationClick} = this.props;
        // console.log('render');
        const {city, data} = this.state;

        return  (
            /* jshint ignore:start */ // JSX is not supported
            <div className="weatherLocationContainer" onClick={onWeatherLocationClick}>
                <Location city={city}></Location>
                { data ?
                  <WeatherData data={data}></WeatherData> :
                  <CircualrProgress size={50}></CircualrProgress>
                }
                {/* <button onClick={this.handleUpdateClick}>Actualizar</button> */}
            </div>
            /* jshint ignore:end */
        );
    }
}

WeatherLocation.propTypes = {
    city: PropTypes.string.isRequired,
    onWeatherLocationClick: PropTypes.func,
}

export default WeatherLocation;
