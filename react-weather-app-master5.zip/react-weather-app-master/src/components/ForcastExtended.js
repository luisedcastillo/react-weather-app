import React, {Component} from 'react';
import PropTypes from 'prop-types';

class ForcastExtended extends Component {

    // constructor(props){
    //     super(props)
    // }

    render(){
        const {city} = this.props;
        return (<div>Pronostico extendido para {city}</div>);  
    }
}

ForcastExtended.propTypes = {
    city: PropTypes.string.isRequired
}

export default ForcastExtended;