import React from 'react';
import WeatherIcons from 'react-weathericons';
import PropTypes from 'prop-types';
import './styles.css';
import {
    CLOUD,
    SUN,
    RAIN,
    SNOW, 
    THUNDER,
    DRIZZLE
} from '../../../constants/weathers';

const icons = {
    [CLOUD]: "cloud",
    [SUN]: "day-sunny",
    [RAIN]: "rain",
    [SNOW]: "snow",
    [THUNDER]: "day-thunderstorm",
    [DRIZZLE]: "day-showers"
};

const defaultStyle = {
    icon: "na",
    size: "4x"
};

const getWeatherIcon = weatherState => {
    const icon = icons[weatherState]; 
    return icon ? icon : defaultStyle.icon;
};

const WeatherTemperature = ({ temp, weatherState }) => (
    /* jshint ignore:start */ // JSX is not supported
    <div className="weatherTempContainer">
        <WeatherIcons className="wicon" name={ getWeatherIcon(weatherState) } size={defaultStyle.size}></WeatherIcons>
        <span className="temperature">{`${temp}`} </span>
        <span className="temperatureType">{' C°'}</span>
    </div>
    /* jshint ignore:end */
);

WeatherTemperature.propTypes = {
    temp: PropTypes.number.isRequired,
    weatherState: PropTypes.oneOf([CLOUD, SUN, RAIN, SNOW, DRIZZLE, THUNDER]).isRequired
};

export default WeatherTemperature;