import React from 'react';
import WeatherInfo from './WeatherInfo';
import WeatherTemperature from './WeatherTemperature';
import PropTypes from 'prop-types';
import './styles.css';

const WeaterData = ({data: {temp, humidity, weatherStatus, wind}}) =>
    //const {temp, humidity, weatherStatus, wind} = data;
    (
        /* jshint ignore:start */ // JSX is not supported
        <div className="weatherDataContainer">
            <WeatherTemperature 
                temp={temp} 
                weatherState={weatherStatus}>
            </WeatherTemperature>
            <WeatherInfo 
                humidity={humidity} 
                wind={wind}>
            </WeatherInfo>
        </div>
        /* jshint ignore:end */
    );

WeaterData.propTypes = {
    data: PropTypes.shape({
        temp: PropTypes.number.isRequired,
        weatherStatus: PropTypes.string.isRequired,
        humidity: PropTypes.number.isRequired,
        wind: PropTypes.string.isRequired
    })
};

export default WeaterData;