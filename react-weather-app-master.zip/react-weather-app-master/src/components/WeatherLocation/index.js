import React from 'react';
import Location from './Locartion';
import WeatherData from './WeatherData';
import './styles.css'

const WeatherLocation = () => (
    /* jshint ignore:start */ // JSX is not supported
    <div className="weatherLocationContainer">
        <Location city={'Saltillo'}></Location>
        <WeatherData></WeatherData>
    </div>
    /* jshint ignore:end */
);

export default WeatherLocation;
