import React from 'react';
import WeatherIcons from 'react-weathericons'
import PropTypes from 'prop-types'
import './styles.css'
import {
    CLOUD,
    CLOUDY,
    SUN,
    RAIN,
    SNOW,
    WINDY,
    FOG
} from '../../../constants/weathers'

const icons = {
    [CLOUD]: "cloud",
    [CLOUDY]: "cloudy",
    [SUN]: "day-sunny",
    [FOG]: "day-fog",
    [RAIN]: "rain",
    [SNOW]: "snow",
    [WINDY]: "windy"
}

const defaultStyle = {
    icon: "na",
    size: "4x"
}

const getWeatherIcon = weatherState => {
    const icon = icons[weatherState]; 
    return icon ? icon : defaultStyle.icon;
}

const WeatherTemperature = ({ temp, weatherState }) => (
    /* jshint ignore:start */ // JSX is not supported
    <div className="weatherTempContainer">
        <WeatherIcons className="wicon" name={ getWeatherIcon(weatherState) } size={defaultStyle.size}></WeatherIcons>
        <span className="temperature">{`${temp}`} </span>
        <span className="temperatureType">{' C°'}</span>
    </div>
    /* jshint ignore:end */
);

WeatherTemperature.propTypes = {
    temp: PropTypes.number.isRequired,
    weatherState: PropTypes.oneOf([CLOUD, CLOUDY]).isRequired
}

export default WeatherTemperature;