import React from 'react';
import WeatherInfo from './WeatherInfo';
import WeatherTemperature from './WeatherTemperature';
import './styles.css'
import {
    CLOUD,
    CLOUDY,
    SUN,
    RAIN,
    SNOW,
    WINDY,
    FOG
} from '../../../constants/weathers'


const WeaterData = () => (
    /* jshint ignore:start */ // JSX is not supported
    <div className="weatherDataContainer">
        <WeatherTemperature temp={20} weatherState={SUN}></WeatherTemperature>
        <WeatherInfo humidity={15} wind={"10 m/s"}></WeatherInfo>
    </div>
    /* jshint ignore:end */
);

export default WeaterData;