import React from 'react';
import PropTypes from 'prop-types'
import './styles.css'

const WeatherInfo = ({humidity, wind}) => (
    /* jshint ignore:start */ // JSX is not supported
    <div className="weatherInfoContainer">
        <span className="extraInfoText">{`Humedad:${humidity} %`}</span>
        <span className="extraInfoText">{`Vientos:${wind}`}</span>
    </div>
    /* jshint ignore:end */
);

WeatherInfo.propTypes = {
    humidity: PropTypes.number.isRequired,
    wind: PropTypes.string.isRequired
};

export default WeatherInfo;