import React from 'react';
import PropTypes from 'prop-types';
import CustomerListItem from './customer-list-item';

const customerRender = (customers, baseUrl) => {

    console.log(customers);

    return customers &&
            customers.map(customer => (
                <CustomerListItem
                    key={customer.id}
                    id={customer.id}
                    name={customer.name}
                    editAction={'editar'}
                    deleteAction={'eliminar'}
                    baseUrl={baseUrl}>
                </CustomerListItem>
            ));
};

const CustomerList = ({customers, baseUrl}) => {
    return (
        <div className="customer-list">
            {
                customerRender(customers, baseUrl)
            }
        </div>
    );
};

CustomerList.propTypes = {
    customers: PropTypes.arrayOf(PropTypes.shape({
        name: PropTypes.string.isRequired,
        id: PropTypes.string.isRequired
    })).isRequired,
    baseUrl: PropTypes.string.isRequired,
};

export default CustomerList;