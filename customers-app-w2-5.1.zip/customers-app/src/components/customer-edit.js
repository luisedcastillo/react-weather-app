import React from 'react';
import PropTypes from 'prop-types';
import { reduxForm, Field } from 'redux-form';
import { withInitialValues } from '../higher-order-components/with-initial-values';
import CustomerActions from './../components/customer-actions';

// const isRequired = value => (
//     !value && "Oblgatorio..."
// );

const validateForm = values => {
    const error = {};

    if(!values.name){
        error.name = 'El campo nombre es requerido';
    }

    if(!values.id){
        error.id = 'El campo ID es requerido';
    }

    return error;
};

const isNumber = value => (
    isNaN(Number(value)) && 'Numerico....'
);

const MyCustomField = ({input, meta, type, name, label}) => (
    <div>
        <label htmlFor={name}>{label}</label>
        <input {...input} type={type ? type : 'text'} />
        {
            meta.touched && meta.error && <span>{meta.error}</span>
        }
    </div>
);

const toNumber = (value) => value && Number(value);

const CustomerEdit = ({name, id, age, handleSubmit, submitting, onBack}) => {
    return (
        <div className="customer-edit">
            <h3>Editar cliente:</h3>
            <form onSubmit={handleSubmit}>
                <Field 
                    name="name" 
                    component={MyCustomField} 
                    type="text"
                  //  validate={isRequired}
                    label="Nombre">
                </Field>
                <Field 
                    name="id" 
                    component={MyCustomField} 
                    type="text"
                    validate={[isNumber]}
                    label="ID">
                </Field>
                <Field 
                    name="age" 
                    component={MyCustomField} 
                    type="number"
                    validate={[isNumber]}
                    parse={toNumber}
                    label="Edad"></Field>
                <CustomerActions>
                    <button type="submit" disabled={submitting}>Aceptar</button>
                    <button type="submit" disabled={submitting} onClick={onBack}>Cancelar</button>
                </CustomerActions>
            </form>
        </div>
    );
};

CustomerEdit.propTypes = {
    name: PropTypes.string.isRequired,
    id: PropTypes.string.isRequired,
    age: PropTypes.number.isRequired,
    onBack: PropTypes.func,
};

const customerEditForm = reduxForm(
    {
        form: 'CustomerEdit',
        validate: validateForm

    })(CustomerEdit);

export default withInitialValues(customerEditForm);