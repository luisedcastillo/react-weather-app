
import {FETCH_CUSTOMERS} from './../constants/actions-types';
import { createAction } from 'redux-actions';

import { get } from './../api';
import { customersUrl } from './../constants/urls'
// export const fetchCustomers = payload => {

//     return ({
//         type: FETCH_CUSTOMERS,
//         payload
//     })
// };


const apiFetchCustomers = () => fetch(customersUrl).then(response => response.json());

export const fetchCustomers = createAction(FETCH_CUSTOMERS, apiFetchCustomers);