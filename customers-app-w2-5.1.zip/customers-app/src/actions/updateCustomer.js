import { createAction } from 'redux-actions';
import { UPDATE_CUSTOMER } from './../constants/actions-types';
import { put } from './../api';
import { customersUrl } from './../constants/urls';

export const updateCustomer = createAction(UPDATE_CUSTOMER,
        (id, customer) => put(customersUrl, id, customer));