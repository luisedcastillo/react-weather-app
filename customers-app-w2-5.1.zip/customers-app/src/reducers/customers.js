import { handleActions } from 'redux-actions';
import { FETCH_CUSTOMERS } from '../constants/actions-types';

export const customers = handleActions({
    [FETCH_CUSTOMERS]: (state, action) => action.payload //[...action.payload]
}, []);