import React, { Component } from 'react';
import PropTypes from 'prop-types';
import CustomerList from './../components/customer-list';
import AppFrame from '../components/app-frame';
import CustomerActions from '../components/customer-actions';

const customers = [
    {
        id: '290000',
        name: 'Luis Castillo',
        age: 30
    },
    {
        id: '120000',
        name: 'Luz Maria Valenzuela',
        age: 20
    },
    {
        id: '980000',
        name: 'Leonardo Castillo',
        age: 1
    },
];

class CustomersContainer extends Component {

    handleAddNew = () => {
        console.log('Add new Clicked');
    }
    
    renderBody = customers => (
        <div>
            <CustomerList 
                customers={customers}
                baseUrl='customer/'>
            </CustomerList>
            <CustomerActions>
                <button onClick={this.handleAddNew}>Nuevo</button>
            </CustomerActions>
        </div>
    )

    render(){
        return (
            <div className="customers-container">
                <AppFrame
                    header="Listado de Clientes"
                    body={this.renderBody(customers)}>

                </AppFrame>
            </div>
        );
    }
}

export default CustomersContainer;