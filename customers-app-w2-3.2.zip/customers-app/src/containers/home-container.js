import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { withRouter } from 'react-router-dom';
import AppFrame from './../components/app-frame';
import CustomerActions from './../components/customer-actions';


class HomeContainer extends Component {


    handleOnClick = () => {
        console.log('hanleOn Click');
        this.props.history.push('/customers');
    }

    render() {
        return(
            <div className="home-container">
                <AppFrame
                    header="Home"
                    body={
                        <div>
                            Esta es la pantalla inicial
                            <CustomerActions>
                                {/* <Link to="/customers">Listado de clientes</Link> */}
                                <button onClick={this.handleOnClick}>Listado de clientes.</button>
                            </CustomerActions>
                        </div>
                    }>
                </AppFrame>
            </div>
        );
    }
};

HomeContainer.propTypes = {

};

export default withRouter(HomeContainer);