import React from 'react';
import PropTypes from 'prop-types';

const CustomerData = ({name, id, age}) => {
    return(
        <div className="customer-data">
            <h3>Datos del cliente</h3>
            <div>
                <span>Nombre:</span>
                {name}
            </div>
            <div>
                <span>ID:</span>
                {id}
            </div>
            <div>
                <span>Edad:</span>
                {age}
            </div>
        </div>
    );
};

CustomerData.propTypes = {
    name: PropTypes.string.isRequired,
    id: PropTypes.string.isRequired,
    age: PropTypes.number,
};

export default CustomerData;