import React from 'react';
import PropTypes from 'prop-types';

const CustomerEdit = ({name, id, age}) => {
    return (
        <div className="customer-edit">
            <h3>Editar cliente:</h3>
            <h4>{name} / {id} / {age}</h4>
        </div>
    );
};

CustomerEdit.propTypes = {
    name: PropTypes.string.isRequired,
    id: PropTypes.string.isRequired,
    age: PropTypes.number.isRequired,
};

export default CustomerEdit;