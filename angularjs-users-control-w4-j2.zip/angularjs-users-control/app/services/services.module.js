(function(){
    'use strict';

    angular
        .module('userControl.services',[]);

})();