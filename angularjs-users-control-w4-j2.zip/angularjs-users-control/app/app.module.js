(function(){
    'use strict';

    angular
        .module('app', [
            'userControl.services'
        ]);
})();