import React from 'react';
import PropTypes from 'prop-types';
import WeatherLocation from './WeatherLocation';
import './styles.css';


const LocationList = ({cities, onLocationSelected}) => {
    
    const handleWeatherLocationClick = city => {
        console.log('handleWeatherLocationClick');
        onLocationSelected(city);
    };


    const getComponents = cities => (
        cities.map(city => 
            <WeatherLocation 
                key={city} 
                city={city}
                onWeatherLocationClick={() => handleWeatherLocationClick(city)}>
            </WeatherLocation>
        )
    );
    
    return (
        <div className='locationList'>
            {getComponents(cities)}
        </div>
    );
};

LocationList.propTypes = {
    cities: PropTypes.array.isRequired,
    onLocationSelected: PropTypes.func
};

export default LocationList