import React from 'react';
import PropTypes from 'prop-types';
import WeatherData from './../WeatherLocation/WeatherData'

const ForecastItem = ({weekDay, hour, data}) => (
    /* jshint ignore:start */ // JSX is not supported
    <div>
        <h2>{weekDay} - {hour} hr.</h2>
        <WeatherData data={data}></WeatherData>
    </div>
    /* jshint ignore:end */ // JSX is not supported
);

ForecastItem.propTypes = {
    weekDay: PropTypes.string.isRequired,
    hour: PropTypes.number.isRequired,
    data: PropTypes.shape({
        temp: PropTypes.number.isRequired,
        weatherStatus: PropTypes.string.isRequired,
        humidity: PropTypes.number.isRequired,
        wind: PropTypes.string.isRequired
    })
};

export default ForecastItem;
