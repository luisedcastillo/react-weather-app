This project was developed by AngularJS

Below you will find some information on how to perform common tasks.<br>


## Quick Start

```
  npm install
  json-server --watch db.json --port 3030
  http-server -o
```

  If you don't have json-server:

```
  npm install -g json-server
```

  If you don't have http-server:

```
  npm install -g http-server
```