(function(){
    'use strict';

    angular
        .module('app', [
            //App Modules
            'userControl.services',
            'userControl.users',

            //Third Party Modules
            'ui.router'
        ]);
})();