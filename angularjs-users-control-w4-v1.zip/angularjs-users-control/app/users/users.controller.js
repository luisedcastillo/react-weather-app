(function(){
    'use strict';

    angular 
        .module('userControl.users')
        .controller('UsersController', UsersController);

    function UsersController(){
        var vm = this;

        vm.getUserImage = getUserImage;
        vm.getUserBack = getUserBack;
        vm.users = [
            {
              "id": 1,
              "name": "Rene Graham",
              "username": "Bret",
              "email": "Sincere@april.biz",
              "phone": "1-770-736-8031 x56442",
              "website": "hildegard.org",
              "gender": "male"
            },
            {
              "id": 2,
              "name": "Ervin Howell Ali",
              "username": "Antonette",
              "email": "Shanna@melissa.tv",
              "phone": "010-692-6593 x09125",
              "website": "anastasia.net",
              "gender": "male"
            },
            {
              "id": 3,
              "name": "Samantha Brion",
              "username": "SamanthaBr",
              "email": "Samantha@yesenia.net",
              "phone": "1-463-123-8888",
              "website": "Samantha.info.com",
              "gender": "female"
            },
            {
              "id": 4,
              "name": "Patricia Lebsack",
              "username": "Karianne",
              "email": "Julianne.OConner@kory.org",
              "address": {
                "street": "Hoeger Mall",
                "suite": "Apt. 692",
                "city": "South Elvis",
                "zipcode": "53919-4257",
                "geo": {
                  "lat": "29.4572",
                  "lng": "-164.2990"
                }
              },
              "phone": "493-170-9623 x156",
              "website": "kale.biz",
              "company": {
                "name": "Robel-Corkery",
                "catchPhrase": "Multi-tiered zero tolerance productivity",
                "bs": "transition cutting-edge web services"
              }
            },
            {
              "id": 5,
              "name": "Chelsey Dietrich",
              "username": "Kamren",
              "email": "Lucio_Hettinger@annie.ca",
              "address": {
                "street": "Skiles Walks",
                "suite": "Suite 351",
                "city": "Roscoeview",
                "zipcode": "33263",
                "geo": {
                  "lat": "-31.8129",
                  "lng": "62.5342"
                }
              },
              "phone": "(254)954-1289",
              "website": "demarco.info",
              "company": {
                "name": "Keebler LLC",
                "catchPhrase": "User-centric fault-tolerant solution",
                "bs": "revolutionize end-to-end systems"
              }
            },
            {
              "id": 6,
              "name": "Mrs. Dennis Schulist",
              "username": "Leopoldo_Corkery",
              "email": "Karley_Dach@jasper.info",
              "address": {
                "street": "Norberto Crossing",
                "suite": "Apt. 950",
                "city": "South Christy",
                "zipcode": "23505-1337",
                "geo": {
                  "lat": "-71.4197",
                  "lng": "71.7478"
                }
              },
              "phone": "1-477-935-8478 x6430",
              "website": "ola.org",
              "company": {
                "name": "Considine-Lockman",
                "catchPhrase": "Synchronised bottom-line interface",
                "bs": "e-enable innovative applications"
              }
            },
            {
              "id": 7,
              "name": "Kurtis Weissnat",
              "username": "Elwyn.Skiles",
              "email": "Telly.Hoeger@billy.biz",
              "address": {
                "street": "Rex Trail",
                "suite": "Suite 280",
                "city": "Howemouth",
                "zipcode": "58804-1099",
                "geo": {
                  "lat": "24.8918",
                  "lng": "21.8984"
                }
              },
              "phone": "210.067.6132",
              "website": "elvis.io",
              "company": {
                "name": "Johns Group",
                "catchPhrase": "Configurable multimedia task-force",
                "bs": "generate enterprise e-tailers"
              }
            },
            {
              "id": 8,
              "name": "Nicholas Runolfsdottir V",
              "username": "Maxime_Nienow",
              "email": "Sherwood@rosamond.me",
              "address": {
                "street": "Ellsworth Summit",
                "suite": "Suite 729",
                "city": "Aliyaview",
                "zipcode": "45169",
                "geo": {
                  "lat": "-14.3990",
                  "lng": "-120.7677"
                }
              },
              "phone": "586.493.6943 x140",
              "website": "jacynthe.com",
              "company": {
                "name": "Abernathy Group",
                "catchPhrase": "Implemented secondary concept",
                "bs": "e-enable extensible e-tailers"
              }
            },
            {
              "id": 9,
              "name": "Glenna Reichert",
              "username": "Delphine",
              "email": "Chaim_McDermott@dana.io",
              "address": {
                "street": "Dayna Park",
                "suite": "Suite 449",
                "city": "Bartholomebury",
                "zipcode": "76495-3109",
                "geo": {
                  "lat": "24.6463",
                  "lng": "-168.8889"
                }
              },
              "phone": "(775)976-6794 x41206",
              "website": "conrad.com",
              "company": {
                "name": "Yost and Sons",
                "catchPhrase": "Switchable contextually-based project",
                "bs": "aggregate real-time technologies"
              }
            },
            {
              "id": 10,
              "name": "Clementina DuBuque",
              "username": "Moriah.Stanton",
              "email": "Rey.Padberg@karina.biz",
              "phone": "024-648-3804",
              "website": "ambrose.net",
              "gender": "female"
            }
          ];


        ////////////////

        function getGenderUrl(gender){
            return gender === 'male' ? 'men' : 'women';
        }

        function getUserBack(gender){
            var genderUrl = '/' + getGenderUrl(gender);

            var url = '../../assets/img' + genderUrl + '-back.jpg';
            return url;
        }

        function getUserImage(user){
            var genderUrl = '/' + getGenderUrl(user.gender);
            var idUrl = '/' + user.id + '.jpg'; 
            var url = 'https://randomuser.me/api/portraits/' + genderUrl + idUrl; 
            
            return url;
        }
    }
})();