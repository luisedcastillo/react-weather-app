(function(){
    'use strict'

    angular
        .module('app')
        .config(configureRoutes);

    configureRoutes.$inject = ['$stateProvider','$urlRouterProvider']

    function configureRoutes($stateProvider, $urlRouterProvider) {

        $urlRouterProvider.otherwise("/home");

        var homeState = {
            name: 'home',
            url: '/home',
            template: '<h3>Its the UI-Router hello world app!</h3>'
        }

        var aboutState = {
            name: 'about',
            url: '/about',
            template: '<h3>About hello world app!</h3>'
        }

        var usersState = {
            name: 'users',
            url: '/users',
            templateUrl: './app/users/users.html',
            controller: 'UsersController',
            controllerAs: 'vm'
        }


        $stateProvider.state(homeState);
        $stateProvider.state(aboutState);
        $stateProvider.state(usersState);

        console.log($stateProvider);
    }

})();