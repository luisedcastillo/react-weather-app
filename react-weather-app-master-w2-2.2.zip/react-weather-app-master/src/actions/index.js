import {getForecastUrlByCity, getWeatherUrlByCity} from './../services/getUrls';
import convertForecast from './../services/convertForecast';
import convertWeather from './../services/converterWeather';

export const SET_CITY = 'SET_CITY';
export const SET_FORECAST_DATA = 'SET_FORECAST_DATA';
export const SET_WEATHER = 'SET_WEATHER';
export const GET_WEATHER_CITY = 'GET_WEATHER_CITY';
export const SET_WEATHER_CITY = 'SET_WEATHER_CITY';

const setCity = payload => ({ type: SET_CITY, payload: payload });
const setForecastData = payload => ({type: SET_FORECAST_DATA, payload});

const getWeatherCity = payload => ({type: GET_WEATHER_CITY, payload});
const setWeatherCity = payload => ({type: SET_WEATHER_CITY, payload});

export const setSelectedCity = payload => {
    return (dispatch, getState) => {

        dispatch(setCity(payload));

        //fetch or axios
        const apiForecast= getForecastUrlByCity(payload);
        const state = getState();
        const timestamp = state.cities[payload] && state.cities[payload].forecastDataTimestamp;
        const now = new Date();

        if(timestamp && (now - timestamp) < 1 * 60 * 1000 ){ // minuto
            return;
        }

        return fetch(apiForecast)
        .then(resolve => {
            return resolve.json();
        })
        .then(data => {
            const forecastData = convertForecast(data);
            dispatch(setForecastData({city: payload, forecastData}))
        });
    };
};


export const setWeather = payload => {
    return dispatch => {
        payload.forEach(city => {
            dispatch(getWeatherCity(city));
            const apiWeather = getWeatherUrlByCity(city);
            fetch(apiWeather)
            .then(resolve => {
                return resolve.json();
            })
            .then(data => {
               
                const newWeather = convertWeather(data);
                dispatch(setWeatherCity({city, weather: newWeather}));
            });
        });
    }

    // handleUpdateClick(){ 
    //     // console.log('handleUpdateClick');
    //     const apiWeather = getWeatherUrlByCity(this.state.city);
    //     fetch(apiWeather)
    //     .then(resolve => {
    //         // console.log(resolve);
    //         return resolve.json();
    //     })
    //     .then(data => {
    //         // console.log('fetch data');
    //         const newWeather = convertWeather(data);
    //         // console.log(newWeather);
    //         this.setState({ 
    //             data: newWeather
    //         });
    //     });
    // }
};