import {combineReducers} from 'redux';
import {createSelector} from 'reselect';
import {city} from './city';
import {cities, 
        getForecastDataFromCities as _getForecastDataFromCities,
        getCitiesWeather as _getCitiesWeather} from './cities';

export default combineReducers({
    cities,
    city
});

// export const getCity = state => state.city;
// export const getForecastDataFromCities = state => _getForecastDataFromCities(state.cities, state.city);

export const getCity = createSelector(state => state.city, city => city);
export const getForecastDataFromCities = createSelector(state => state.cities, getCity, _getForecastDataFromCities);
export const getCitiesWeather = createSelector(state => state.cities, _getCitiesWeather);