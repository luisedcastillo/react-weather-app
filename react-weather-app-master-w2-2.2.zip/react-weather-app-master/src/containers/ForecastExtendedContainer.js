import React, { Component } from 'react';
import PropTypes from 'prop-types';
import ForecastExtended from '../components/ForecastExtended';
import { getForecastDataFromCities, getCity } from './../reducers';
import { connect } from 'react-redux';

class ForecastExtendedContainer extends Component {
    render(){
        const {city, forecastData} = this.props;
        return (
            /* jshint ignore:start */ // JSX is not supported
            this.props.city &&
            <ForecastExtended city={city} forecastData={forecastData}></ForecastExtended>
            /* jshint ignore:end */ // JSX is not supported
        );
    }
}

ForecastExtendedContainer.propTypes = {
    city: PropTypes.string.isRequired,
    forecastData: PropTypes.array
};

const mapStateToProps = (state) => ({city: getCity(state), forecastData:getForecastDataFromCities(state)});
//forecastData: getForecastDataFromCities(state, state.city)
//cities[city] && cities[city].forecastData
export default connect(mapStateToProps, null)(ForecastExtendedContainer);