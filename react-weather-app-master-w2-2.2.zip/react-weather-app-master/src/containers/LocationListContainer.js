import React, { Component } from 'react';
import { bindActionCreators } from 'redux';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import * as actions from '../actions';
import { getCitiesWeather, getCity } from '../reducers';
import LocationList from '../components/LocationList';

class LocationListContainer extends Component {

    componentDidMount() {
        const {setWeather, setSelectedCity, cities, city } = this.props;

        setWeather(cities);
        setSelectedCity(city);
    }

    handleLocationSelected = city => {
        this.props.setSelectedCity(city);
    }

    render(){
        return (
            /* jshint ignore:start */ // JSX is not supported
            <LocationList 
                cities={this.props.citiesWeather}
                onLocationSelected={this.handleLocationSelected}>
            </LocationList>
            /* jshint ignore:end */ // JSX is not supported
        );
    }
}

LocationListContainer.propTypes = {
    setSelectedCity: PropTypes.func.isRequired,
    setWeather: PropTypes.func.isRequired,
    cities: PropTypes.array.isRequired,
    citiesWeather: PropTypes.array,
    city: PropTypes.string.isRequired,
};

const mapDispatcherToProps = dispatch => bindActionCreators(actions, dispatch);

// const mapDispatcherToProps = dispatch => ({
//     setSelectedCity: value => dispatch(setSelectedCity(value)),
//     setWeather: cities => dispatch(setWeather(cities))
// });

const mapStateToProps = state => ({
    citiesWeather: getCitiesWeather(state),
    city: getCity(state)
});

export default connect(mapStateToProps, mapDispatcherToProps)(LocationListContainer);