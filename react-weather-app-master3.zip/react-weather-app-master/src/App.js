import React, { Component } from 'react';
import LocationList from './components/LocationList';
import './App.css';

const cities = [
  "Monterrey,mx",
  "Chihuahua,mx",
  "Ciudad de México,mx",
  "Saltillo,mx",
  "Lima,pe",
  "Madrid,es"
]

class App extends Component {

  handleLocationSelected = city => {
    console.log('handleLocationSelected ' + city);
  };

  render() {
    /* jshint ignore:start */ // JSX is not supported
    return (
    <div className="App">
         <LocationList 
            cities={cities}
            onLocationSelected={this.handleLocationSelected}>
          </LocationList>
      </div>
    );
    /* jshint ignore:end */
  }
}

export default App;
