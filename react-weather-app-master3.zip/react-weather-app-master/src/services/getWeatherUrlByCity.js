import { baseUrl, apiKey } from '../constants/apiUrls'

const getWeahterUrlByCity = city => {
   return `${baseUrl}?q=${city}&appid=${apiKey}`;
}

export default getWeahterUrlByCity;